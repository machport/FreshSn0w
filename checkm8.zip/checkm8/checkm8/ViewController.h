

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@property (weak) IBOutlet NSButton *makesn0w;
@property (weak) IBOutlet NSButton *updatebutton;
@property (weak) IBOutlet NSButton *recovery;
@property (weak) IBOutlet NSButton *pwnxout;
@property (weak) IBOutlet NSButton *autobootout;

@end

